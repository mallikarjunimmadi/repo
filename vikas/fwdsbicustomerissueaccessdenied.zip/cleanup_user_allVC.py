import argparse
import json
from base64 import b64encode
import requests
import warnings
warnings.filterwarnings('ignore')  # Suppress all warnings


def get_vc_session_id(vchost, vcusername, vcpassword):
    print('******* getting vc session id  *******')
    auth = b64encode(("%s:%s" % (vcusername, vcpassword)).encode('utf-8')).decode("ascii")
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Basic %s' % auth}
    url = vchost + "/rest/com/vmware/cis/session"
    response = requests.post(url=url, headers=headers, verify=False)
    js = json.loads(response.content)
    return js['value']


def get_tenant_admin_client_token(vidb_host, vc_sessionId):
    headers = {
        'Content-Type': 'application/json',
        'vmware-api-session-id': vc_sessionId}
    url_tenant_admin = vidb_host + "/api/vcenter/identity/broker/tenants/customer/admin-client"
    response_tenant_admin = requests.get(url=url_tenant_admin, headers=headers, verify=False)
    js = json.loads(response_tenant_admin.content)
    return js['access_token']

def search_and_delete_user(vidb_host , tenant_admin_token, userName , domain):
    print('******* getting specific users for the search criteria  *******')
    vidb_headers_usergroup = {
        'Content-Type': 'application/scim+json',
        'Authorization': 'Bearer %s'
    }
    headers = vidb_headers_usergroup
    headers.update({'Authorization': 'Bearer %s' % tenant_admin_token})
    vidb_search_user_payload = {
        "attributes": [
            "emails",
            "urn:ietf:params:scim:schemas:extension:ws1b:2.0:User:name",
            "name.familyName",
            "userName",
            "urn:ietf:params:scim:schemas:extension:ws1b:2.0:User:domain",
            "groups"
        ],
        "filter": "userName eq \"test\" and domain eq \"test\"",
    }
    headers.update({'Authorization': 'Bearer %s' % tenant_admin_token})
    vidb_search_user_payload['filter'] = f'userName eq "{userName}" and domain eq "{domain}"'


    url = vidb_host + "/usergroup/t/CUSTOMER/scim/v2/Users" + "/.search"
    print(vidb_search_user_payload)
    response_get_user = requests.post(url=url, headers=headers, json=vidb_search_user_payload, verify=False)
    js = json.loads(response_get_user.content)
    f1 = open("../results.txt", 'a+')
    if (js['totalResults'] != 0):
         print(js['Resources'][0]['id'])
         print("Delete the user")
         url_delete = vidb_host + "/usergroup/t/CUSTOMER/scim/v2/Users/" + js['Resources'][0]['id']
         response_delete_user = requests.delete(url=url_delete, headers=headers, verify=False)
         print("Delete response:"+ str(response_delete_user.status_code))
         response_get_user = requests.post(url=url, headers=headers, json=vidb_search_user_payload, verify=False)
         js = json.loads(response_get_user.content)
         if response_delete_user.status_code == 204:
              f1.write("User deletion success on VC " + str(vidb_host) + " for " + userName + '\n')
         else:
              f1.write("User deletion failed on VC " + str(vidb_host) + " for " + userName + '\n')
    else:
         f1.write("User not exists on VC " + str(vidb_host) + " for " + userName + '\n')


if __name__ == "__main__":
    with open('vc_data.txt', 'r') as file:
        for line in file:
            vc_detail = line.strip()
            VC_HOST = "https://" + vc_detail.split(',')[0]
            VC_PASSWORD = vc_detail.split(',')[1]
            vc_session_id = get_vc_session_id(VC_HOST, "administrator@vsphere.local", VC_PASSWORD)
            tenant_admin_token = get_tenant_admin_client_token(VC_HOST, vc_session_id)
            #search_and_delete_user(VC_HOST, tenant_admin_token ,"test", "test.com")
            with open('user_data.txt', 'r') as user_file:
                for user in user_file:
                    user_detail = user.strip()
                    search_and_delete_user(VC_HOST, tenant_admin_token, user_detail.split(',')[0],
                                user_detail.split(',')[1])




